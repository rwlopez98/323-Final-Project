package com.example.finalproject.Fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.LandingPageActivity;
import com.example.finalproject.R;
import com.example.finalproject.helperClasses.CardViewAdapter;
import com.example.finalproject.helperClasses.Task;
import com.example.finalproject.helperClasses.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import static android.app.Activity.RESULT_OK;

public class PendingTasksFragment extends Fragment {

    //initalizes global variables

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;

    Button newTask;
    Uri imageUri;
    ImageView uploadPicture;

    private String image;
    private Calendar cal;
    private Calendar timeValue;

    private TimePickerDialog.OnTimeSetListener mTimeSetListener;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    FirebaseUser firebaseUser;
    DatabaseReference reference;

    User user;
    private Task task = new Task();

    ArrayList<Task> fullList;
    ArrayList<Task> notCompleted;
    ArrayList<String> fullTaskIDs;
    ArrayList<String> notCompletedTaskIds;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pending_tasks, container, false);

        //gets the current user information and unique ID

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());

        //retrieves, sorts, and populates the recycler view

        recyclerView = view.findViewById(R.id.recyclerView);
        retreiveAndSort(firebaseUser.getUid());
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);


        //retrives the user's information and puts it in a User object.
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                user = dataSnapshot.getValue(User.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //intializes and sets up the onclick listener for adding a new task
        newTask = view.findViewById(R.id.newTask);
        newTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext()); //opens the first image dialog and inflates it
                View mView = getLayoutInflater().inflate(R.layout.image_dialog, null);

                final Button chooseFromGallery, takeOnCamera, skip;

                uploadPicture = mView.findViewById(R.id.uploadedPicture);

                chooseFromGallery = mView.findViewById(R.id.chooseFromGallery); //opens the image gallery so the user can select their picture
                chooseFromGallery.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Toast.makeText(getContext(), "Gallery Selection", Toast.LENGTH_SHORT).show();
                        Intent gallery = new Intent();
                        gallery.setType("image/*");
                        gallery.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(gallery, "Select Picture"), 1);
                    }
                });

                takeOnCamera = mView.findViewById(R.id.takeOnCamera); //opens the camera to allow the user to take their own picture
                takeOnCamera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Toast.makeText(getContext(), "Take Picture", Toast.LENGTH_SHORT).show();
                        Intent takePic = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(Intent.createChooser(takePic, "Take A Picture"), 2);
                    }
                });

                skip = mView.findViewById(R.id.skipDialog); //opens up and inflates the information dialog, if there was no picture added it uses the default one
                skip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        encodePicture();
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                        View m2View = getLayoutInflater().inflate(R.layout.information_dialogue, null);
                        final EditText titleBox, descriptionBox, addressBox;
                        final TextView dateBox, timeBox;
                        Button saveButton, cancelButton;

                        titleBox = m2View.findViewById(R.id.title);
                        descriptionBox = m2View.findViewById(R.id.description);
                        dateBox = m2View.findViewById(R.id.date);
                        timeBox = m2View.findViewById(R.id.time);
                        addressBox = m2View.findViewById(R.id.location);
                        saveButton = m2View.findViewById(R.id.save);
                        cancelButton = m2View.findViewById(R.id.cancel);

                        dateBox.setOnClickListener(new View.OnClickListener() {
                            @SuppressLint("ResourceAsColor")
                            @Override
                            public void onClick(View view) { //on click listener to open the date picker dialog
                                cal = Calendar.getInstance();
                                int year = cal.get(Calendar.YEAR);
                                int month = cal.get(Calendar.MONTH);
                                int day = cal.get(Calendar.DAY_OF_MONTH);

                                DatePickerDialog datePickerDialog = new DatePickerDialog(
                                        getContext(), android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                        mDateSetListener,
                                        year, month, day);
                                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(R.color.colorPrimaryDark));
                                datePickerDialog.show();
                            }
                        });
                        mDateSetListener = new DatePickerDialog.OnDateSetListener(){
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) { //when the date is set it updates the calender object and updates the dateBox
                                cal.set(year, month, day);
                                month = month + 1;
                                String date = month + "/" + day + "/" + year;
                                dateBox.setText(date);
                            }
                        };

                        timeBox.setOnClickListener(new View.OnClickListener() {
                            @SuppressLint("ResourceAsColor")
                            @Override
                            public void onClick(View view) {//on click listener to open the time picker dialog
                                timeValue = Calendar.getInstance();
                                int hour = timeValue.get(Calendar.HOUR_OF_DAY);
                                int minute = timeValue.get(Calendar.MINUTE);

                                TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(), R.style.DialogTheme, mTimeSetListener, hour, minute, true);
                                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(R.color.colorPrimary));
                                timePickerDialog.show();
                            }
                        });

                        mTimeSetListener = new TimePickerDialog.OnTimeSetListener(){
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hour, int min) {// the the time is set it updates the calender object and updates the datbox
                                timeValue.set(Calendar.HOUR, hour);
                                timeValue.set(Calendar.MINUTE, min);
                                String time = hour + ":" + min;
                                timeBox.setText(time);
                            }
                        };

                        saveButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {//when save is hit it updates the Task object
                                task.setTaskImage(image);
                                task.setTaskTitle(titleBox.getText().toString());
                                task.setTaskDescription(descriptionBox.getText().toString());
                                task.setTaskYear(cal.YEAR);
                                task.setTaskMonth(cal.MONTH);
                                task.setTaskDay(cal.DAY_OF_MONTH);
                                task.setTaskHour(timeValue.HOUR);
                                task.setTaskMin(timeValue.MINUTE);
                                task.setUserID(user.getId());
                                task.setCompleted(false);

                                Geocoder coder = new Geocoder(getContext());//attempts to get a lat and lng from the given address, otherwise its set to 0, 0
                                List<Address> address;
                                try{
                                    address = coder.getFromLocationName(addressBox.getText().toString(), 1);
                                    if (address.isEmpty()){
                                        Toast.makeText(getContext(), "Unable To Get Longitude and Latitude Location From Input", Toast.LENGTH_SHORT).show();
                                        task.setTaskLat(0);
                                        task.setTaskLon(0);
                                    } else{
                                        Address location = address.get(0);
                                        task.setTaskLat(location.getLatitude());
                                        task.setTaskLon(location.getLongitude());
                                    }
                                } catch (IOException e){
                                    e.printStackTrace();
                                }
                                //checks to see if all the fields have been filled out so that we don't push any empty fields to the database which could cause trouble later
                                if(titleBox.getText().toString().isEmpty() || descriptionBox.getText().toString().isEmpty() || dateBox.getText().toString().isEmpty() || timeBox.getText().toString().isEmpty() || addressBox.getText().toString().isEmpty()){
                                    Toast.makeText(getContext(), "You Must Fill Out All Boxes", Toast.LENGTH_SHORT).show();
                                }else{
                                    sendTask();
                                }

                            }
                        });

                        //Reloads the activity thus destroying all the dialogs and information created up to this point
                        cancelButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                //todo reload activity without database upload
                                startActivity(new Intent(getContext(), LandingPageActivity.class));
                            }
                        });

                        mBuilder.setView(m2View);
                        AlertDialog dialog = mBuilder.create();
                        dialog.show();
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == RESULT_OK){
            imageUri = data.getData();
            try{
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), imageUri);
                uploadPicture.setImageBitmap(bitmap);
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        if(requestCode == 2 && resultCode == RESULT_OK){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            uploadPicture.setImageBitmap(bitmap);
        }
    }

    //reduces the images to 100x100 squres and converts them to Base64 string
    public void encodePicture(){
        BitmapDrawable drawable = (BitmapDrawable) uploadPicture.getDrawable();
        Bitmap bitmap = drawable.getBitmap();
        Bitmap hundredbyhundred = Bitmap.createScaledBitmap(bitmap, 100, 100, false);
        ByteArrayOutputStream byteArrayOutputStream= new ByteArrayOutputStream();
        hundredbyhundred.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

        image = Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    //Puts the task into the database and closes the dialogs when it is all finished
    private void sendTask(){
        DatabaseReference tempReference = FirebaseDatabase.getInstance().getReference();

        String userID = task.getUserID();
        String taskTitle = task.getTaskTitle();
        String taskDescription = task.getTaskDescription();
        int taskYear = cal.get(Calendar.YEAR);
        int taskMonth = cal.get(Calendar.MONTH);
        int taskDay = cal.get(Calendar.DAY_OF_MONTH);
        int taskHour = task.getTaskHour();
        int taskMin = task.getTaskMin();
        double taskLat = task.getTaskLat();
        double taskLon = task.getTaskLon();
        String taskImage = task.getTaskImage();
        boolean completed = task.isCompleted();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("UserID", userID);
        hashMap.put("TaskTitle", taskTitle);
        hashMap.put("TaskDescription", taskDescription);
        hashMap.put("TaskYear", taskYear);
        hashMap.put("TaskMonth", taskMonth);
        hashMap.put("TaskDay", taskDay);
        hashMap.put("TaskHour", taskHour);
        hashMap.put("TaskMin", taskMin);
        hashMap.put("TaskLat", taskLat);
        hashMap.put("TaskLon", taskLon);
        hashMap.put("TaskImage", taskImage);
        hashMap.put("Completed", completed);

        tempReference.child("Task").push().setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull com.google.android.gms.tasks.Task<Void> task) {
                startActivity(new Intent(getContext(), LandingPageActivity.class));
            }
        });
    }

    //Pulls all tasks and sorts them by user, and completed
    private void retreiveAndSort(final String userID){
        fullList = new ArrayList<>();
        notCompleted = new ArrayList<>();
        fullTaskIDs = new ArrayList<>();
        notCompletedTaskIds = new ArrayList<>();

        Toast.makeText(getContext(), "Downloading Tasks", Toast.LENGTH_SHORT).show();
        DatabaseReference tempReference = FirebaseDatabase.getInstance().getReference("Task");
        tempReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fullList.clear();
                fullTaskIDs.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Task task = snapshot.getValue(Task.class);
                    if(task.getUserID().equals(userID)){
                        fullList.add(task);
                        fullTaskIDs.add(snapshot.getKey());
                    }
                }
                notCompleted.clear();
                notCompletedTaskIds.clear();
                for(Task task : fullList){
                    Task current = task;
                    if(current.isCompleted()==false){
                        notCompleted.add(current);
                        notCompletedTaskIds.add(fullTaskIDs.get(fullList.indexOf(current)));
                    }
                }
                if(notCompleted.isEmpty()){
                    Toast.makeText(getContext(), "You Have No Pending Task", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Pending Tasks Downloaded Successfully", Toast.LENGTH_SHORT).show();
                }
                adapter = new CardViewAdapter(notCompleted, getContext());
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //Handles swiping the recycler to the right
    ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            updateComplete(notCompletedTaskIds.get(viewHolder.getAdapterPosition()), notCompleted.get(viewHolder.getAdapterPosition()));
            notCompleted.remove(viewHolder.getAdapterPosition());
            adapter.notifyDataSetChanged();
        }
    };

    //updates the task to complete if it is swiped.
    public void updateComplete(String taskID, Task taskInfo){
        Task taskToUpdate = taskInfo;
        taskToUpdate.setCompleted(true);

        DatabaseReference tempReference = FirebaseDatabase.getInstance().getReference("Task");
        tempReference.child(taskID).setValue(taskToUpdate);
    }
}
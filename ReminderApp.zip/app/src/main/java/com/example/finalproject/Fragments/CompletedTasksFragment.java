package com.example.finalproject.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;
import com.example.finalproject.helperClasses.CardViewAdapter;
import com.example.finalproject.helperClasses.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

//Copied most the code over from the pending fragment, stripped it down, and to sort the tasks by checking for completion

public class CompletedTasksFragment extends Fragment {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;

    FirebaseUser firebaseUser;
    DatabaseReference reference;

    ArrayList<Task> fullList;
    ArrayList<Task> completed;
    ArrayList<String> fullTaskIDs;
    ArrayList<String> completedTaskIds;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_completed_tasks, container, false);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());

        recyclerView = view.findViewById(R.id.recyclerView);
        retreiveAndSort(firebaseUser.getUid());
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        return view;
    }

    private void retreiveAndSort(final String userID){
        fullList = new ArrayList<>();
        completed = new ArrayList<>();
        fullTaskIDs = new ArrayList<>();
        completedTaskIds = new ArrayList<>();

        Toast.makeText(getContext(), "Downloading Tasks", Toast.LENGTH_SHORT).show();
        DatabaseReference tempReference = FirebaseDatabase.getInstance().getReference("Task");
        tempReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fullList.clear();
                fullTaskIDs.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Task task = snapshot.getValue(Task.class);
                    if(task.getUserID().equals(userID)){
                        fullList.add(task);
                        fullTaskIDs.add(snapshot.getKey());
                    }
                }
                completed.clear();
                completedTaskIds.clear();
                for(Task task : fullList){
                    Task current = task;
                    if(current.isCompleted()==true){
                        completed.add(current);
                        completedTaskIds.add(fullTaskIDs.get(fullList.indexOf(current)));
                    }
                }
                //Toast.makeText(getContext(), fullList.size()+"", Toast.LENGTH_SHORT).show();
                //Toast.makeText(getContext(), notCompleted.get(0).getTaskTitle()+"", Toast.LENGTH_SHORT).show();
                if(completed.isEmpty()){
                    Toast.makeText(getContext(), "You Have No Completed Tasks", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Completed Tasks Downloaded Successfully", Toast.LENGTH_SHORT).show();
                }
                adapter = new CardViewAdapter(completed, getContext());
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
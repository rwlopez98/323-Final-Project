package com.example.finalproject.helperClasses;

import java.util.Calendar;

//Handles the cardView used in the recycler view

public class cardViewItems {
    private String imageResourceURL;
    private String taskName, description;
    Calendar dueDate;
    boolean completed;
    double longitude;
    double lattitude;

    public cardViewItems(String imageResourceURL, String taskName, String description, Calendar dueDate, boolean completed, double longitude, double lattitude) {
        this.imageResourceURL = imageResourceURL;
        this.taskName = taskName;
        this.description = description;
        this.dueDate = dueDate;
        this.completed = completed;
        this.longitude = longitude;
        this.lattitude = lattitude;
    }

    public String getImageResourceURL() {
        return imageResourceURL;
    }

    public void setImageResourceURL(String imageResourceURL) {
        this.imageResourceURL = imageResourceURL;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Calendar getDueDate() {
        return dueDate;
    }

    public void setDueDate(Calendar dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLattitude() {
        return lattitude;
    }

    public void setLattitude(double lattitude) {
        this.lattitude = lattitude;
    }
}
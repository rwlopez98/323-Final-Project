package com.example.finalproject.helperClasses;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;

import java.util.ArrayList;

public class CardViewAdapter extends RecyclerView.Adapter<CardViewAdapter.CardViewHolder>{

    ArrayList<Task> mTaskList;
    Context mContext;

    public static class CardViewHolder  extends RecyclerView.ViewHolder{
        public TextView taskName, description, dueDateText, dueDateNumber;
        public ImageView taskPicture;

        public CardViewHolder(@NonNull View itemView) {
            super(itemView);
            taskPicture = itemView.findViewById(R.id.taskPicture);
            taskName = itemView.findViewById(R.id.taskName);
            description = itemView.findViewById(R.id.description);
            dueDateText = itemView.findViewById(R.id.dueDateText);
            dueDateNumber = itemView.findViewById(R.id.dueDateNumber);
        }
    }

    public CardViewAdapter(ArrayList<Task> taskList, Context mContext){
        this.mContext = mContext;
        this.mTaskList = taskList;
    }

    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.card_view_layout, parent, false);
        CardViewHolder cvh = new CardViewHolder(v);
        return cvh;
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewHolder holder, int position) {
        Task currentTask = mTaskList.get(position);

        String encoded = currentTask.getTaskImage();
        byte[] byteArray = Base64.decode(encoded, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        holder.taskPicture.setImageBitmap(bitmap);

        holder.taskName.setText(currentTask.getTaskTitle());
        holder.description.setText(currentTask.getTaskDescription());
        holder.dueDateText.setText("Due Date:");
        holder.dueDateNumber.setText(1+(currentTask.getTaskMonth()) + "/" + currentTask.getTaskDay() + "/" + currentTask.getTaskYear());
    }

    @Override
    public int getItemCount() {
        return mTaskList.size();
    }
}

package com.example.finalproject.helperClasses;

public class Task {
    private String UserID, TaskTitle, TaskDescription, TaskImage;
    private int TaskYear, TaskMonth, TaskDay, TaskHour, TaskMin;
    private double TaskLat, TaskLon;
    private boolean Completed;

    //handles tasks to be uploaded and downloaded from the database

    public Task(String task_ID, String userID, String task_Title, String task_Description, String task_Image, int year, int month, int day, int hour, int min, int lat, int lon, boolean completed) {
        this.UserID = userID;
        this.TaskTitle = task_Title;
        this.TaskDescription = task_Description;
        this.TaskImage = task_Image;
        this.TaskYear = year;
        this.TaskMonth = month;
        this.TaskDay = day;
        this.TaskHour = hour;
        this.TaskMin = min;
        this.TaskLat = lat;
        this.TaskLon = lon;
        this.Completed = completed;
    }

    public Task() {

    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getTaskTitle() {
        return TaskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        TaskTitle = taskTitle;
    }

    public String getTaskDescription() {
        return TaskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        TaskDescription = taskDescription;
    }

    public String getTaskImage() {
        return TaskImage;
    }

    public void setTaskImage(String taskImage) {
        TaskImage = taskImage;
    }

    public int getTaskYear() {
        return TaskYear;
    }

    public void setTaskYear(int taskYear) {
        TaskYear = taskYear;
    }

    public int getTaskMonth() {
        return TaskMonth;
    }

    public void setTaskMonth(int taskMonth) {
        TaskMonth = taskMonth;
    }

    public int getTaskDay() {
        return TaskDay;
    }

    public void setTaskDay(int taskDay) {
        TaskDay = taskDay;
    }

    public int getTaskHour() {
        return TaskHour;
    }

    public void setTaskHour(int taskHour) {
        TaskHour = taskHour;
    }

    public int getTaskMin() {
        return TaskMin;
    }

    public void setTaskMin(int taskMin) {
        TaskMin = taskMin;
    }

    public double getTaskLat() {
        return TaskLat;
    }

    public void setTaskLat(double taskLat) {
        TaskLat = taskLat;
    }

    public double getTaskLon() {
        return TaskLon;
    }

    public void setTaskLon(double taskLon) {
        TaskLon = taskLon;
    }

    public boolean isCompleted() {
        return Completed;
    }

    public void setCompleted(boolean completed) {
        Completed = completed;
    }
}